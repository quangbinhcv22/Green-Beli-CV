Cartoon FX & War FX Demo
===

Please import assets "Cartoon FX Free" and/or "War FX Free" from Unity asset store.